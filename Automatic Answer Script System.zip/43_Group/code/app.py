from flask import Flask, render_template, request
from keras.preprocessing import image
import pickle
import cv2
import numpy as np

import os
import pandas as pd

import numpy as np
import matplotlib as plt

from keras.preprocessing.text import Tokenizer
from keras_preprocessing.sequence import pad_sequences
from document_similarity import get_document_similarity

import pickle
from keras.models import load_model

from PIL import Image
import pytesseract 



pytesseract.pytesseract.tesseract_cmd = "C:/Program Files/Tesseract-OCR//tesseract"


app = Flask(__name__)


MAX_SEQUENCE_LENGTH = 400
MAX_VOCAB_SIZE = 20000
EMBEDDING_DIM = 50


word2vec = {}

# Glove file path
with open(os.path.join('C:/Users/Deeksha/Desktop/webapp/glove.6B.%sd.txt' %EMBEDDING_DIM), encoding='utf-8') as f:
    # is just a space-seperated text file in the format:
    # word vec[0] vec[1] vec[2]....
    for line in f:
        values = line.split()
        word = values[0]
        vec = np.asarray(values[1:], dtype='float32')
        word2vec[word] = vec


# tokenizer file path
with open('C:/Users/Deeksha/Desktop/webapp/tokenizer.pickle', 'rb') as handle:
    tokenizer = pickle.load(handle)



def predict_label(data):
	# model file path 
	model = load_model('C:/Users/Deeksha/Desktop/webapp/final_lstm.h5')

	marks = model.predict(data)

	return marks


# routes
@app.route("/", methods=['GET', 'POST'])
def main():
	return render_template("index.html")

@app.route("/about")
def about_page():
	return "Please subscribe  Artificial Intelligence Hub..!!!"

@app.route("/submit", methods = ['GET', 'POST'])
def get_output():
	if request.method == 'POST':
		img = request.files['my_image']
		correct_ans_img = request.files['que_image']
		ques = request.form['text']
		weight = request.form['int']
		weight = int(weight)


		img_path = "static/" + img.filename	
		img.save(img_path)

		corr_ans_img_path = "static/" + correct_ans_img.filename	
		correct_ans_img.save(corr_ans_img_path)


		image = Image.open(img_path)
		sentenc = pytesseract.image_to_string(image) 
		if len(sentenc) < 1:
			sentenc = "Text Unrecognized"
		print(len(sentenc))
		sentence  = [sentenc]

		corr_ans_image = Image.open(corr_ans_img_path)
		corr_ans_txt = pytesseract.image_to_string(corr_ans_image)
		if len(corr_ans_txt) < 1:
			corr_ans_txt = "Text Unrecognized"
		print(len(corr_ans_txt))
		#question  = [que]

		sequences = tokenizer.texts_to_sequences(sentence)
		# get word -> integer mapping
		word2idx = tokenizer.word_index

		data = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)

		marks = predict_label(data)
		marks = np.round(marks[0][0])	

		similarity_marks = get_document_similarity (corr_ans_txt, sentenc)
		que_ans_sim = get_document_similarity (corr_ans_txt, ques)
		
		if similarity_marks < 0.20:
			similarity_marks = 0
		elif similarity_marks >0.20 and similarity_marks<0.50:
			similarity_marks = weight*0.25
		elif similarity_marks >0.50 and similarity_marks<0.75:
			similarity_marks = weight*0.75
		else:
			similarity_marks = weight*1
		similarity_marks = np.round(similarity_marks,2)
		
		if que_ans_sim < 0.20:
			que_ans_sim = 0
		elif que_ans_sim >0.20 and que_ans_sim <0.50:
			que_ans_sim = (weight/2)*0.25
		elif que_ans_sim >0.50 and que_ans_sim<0.75:
			que_ans_sim = (weight/2)*0.75
		else:
			que_ans_sim = (weight/2)*1
		que_ans_sim = np.round(que_ans_sim,2)
		
		total_score = ((similarity_marks + que_ans_sim)/2) + marks
		if  total_score < (weight*0.3):
			feedback = "BAD"
		elif  total_score  > (weight*0.3)and total_score < (weight*0.5):
			feedback = "AVERAGE"
		elif total_score > (weight*0.5) and total_score < (weight*0.9):
			feedback = "GOOD"
		else:
			feedback = "EXCELLENT"
		
	return render_template("index.html", question = corr_ans_txt, answer = sentenc,text_ques = ques, mark = marks, sim_marks = similarity_marks,mark_weight = weight, q_a_sim = que_ans_sim, total = np.round(total_score,2), fdbk = feedback) 


if __name__ =='__main__':
	#app.debug = True
	app.run(debug = True)

